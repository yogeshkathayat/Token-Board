import Foundation
import Combine

@MainActor
final class UsageViewModel: ObservableObject {
    @Published private(set) var summary: UsageSummary?
    @Published private(set) var loading: Bool = false
    @Published private(set) var lastError: String?
    @Published var baseURLInput: String = ""
    @Published var tokenInput: String = ""

    var onSummaryChange: ((UsageSummary?) -> Void)?

    private var bag = Set<AnyCancellable>()

    func start() {
        baseURLInput = Settings.shared.baseURL?.absoluteString ?? ""
        // Don't prefill the token field — clearer UX for paste-to-replace.
        tokenInput = ""
        $summary
            .sink { [weak self] s in self?.onSummaryChange?(s) }
            .store(in: &bag)
        refresh()
    }

    var hasStoredToken: Bool {
        (Settings.shared.userToken ?? "").isEmpty == false
    }

    func saveCredentials() {
        if let url = URL(string: baseURLInput.trimmingCharacters(in: .whitespacesAndNewlines)),
           ["http", "https"].contains(url.scheme ?? "") {
            Settings.shared.baseURL = url
        }
        let trimmed = tokenInput.trimmingCharacters(in: .whitespacesAndNewlines)
        FileHandle.standardError.write(Data("[tokenboard] saveCredentials url=\(baseURLInput) tokenLen=\(trimmed.count)\n".utf8))
        if !trimmed.isEmpty {
            Settings.shared.userToken = trimmed
            // Verify it actually wrote
            let stored = Settings.shared.userToken ?? ""
            FileHandle.standardError.write(Data("[tokenboard] stored token len=\(stored.count) match=\(stored == trimmed)\n".utf8))
            tokenInput = ""
        }
        refresh()
    }

    func clearToken() {
        Settings.shared.userToken = nil
        tokenInput = ""
        summary = nil
        lastError = "Token cleared. Paste a new one and tap Done."
    }

    func refresh() {
        let url = Settings.shared.baseURL
        let token = Settings.shared.userToken
        FileHandle.standardError.write(Data("[tokenboard] refresh url=\(url?.absoluteString ?? "nil") token_len=\(token?.count ?? 0)\n".utf8))
        guard let url = url, let token = token, !token.isEmpty else {
            self.summary = nil
            self.lastError = "Not connected — open Settings."
            return
        }
        loading = true
        lastError = nil
        let client = APIClient(baseURL: url, userToken: token)
        Task { [weak self] in
            do {
                // Use the user's local timezone so "today" means midnight-to-
                // midnight in their wallclock, not UTC. The API uses the
                // `tz` query param to align date boundaries.
                let tz = TimeZone.current.identifier
                let today = Self.todayLocal()
                let d6 = Self.daysAgoLocal(6)
                let d29 = Self.daysAgoLocal(29)

                async let todaySum = client.summary(from: today, to: today, tz: tz)
                async let week = client.summary(from: d6, to: today, tz: tz)
                async let month = client.summary(from: d29, to: today, tz: tz)
                // The API caps date ranges at USAGE_MAX_DAYS (default 800)
                // inclusive. daysAgo(798) → 799-day inclusive range, safely
                // under the cap. ~2y2m which is "all time" for any practical
                // engineer's tool history.
                async let total = client.summary(from: Self.daysAgoLocal(798), to: today, tz: tz)
                async let weekDaily = client.daily(from: d6, to: today, tz: tz)
                async let monthBreakdown = client.modelBreakdown(from: d29, to: today, tz: tz)

                let (todayR, weekR, monthR, totalR, weekDailyR, breakdownR) = try await (
                    todaySum, week, month, total, weekDaily, monthBreakdown
                )

                let activeDays = weekDailyR.data.filter { (Int64($0.total_tokens) ?? 0) > 0 }.count

                var modelTotals: [(String, Int64)] = []
                var sourceTotals: [(String, Int64)] = []
                for src in breakdownR.sources {
                    sourceTotals.append((src.source, Int64(src.totals.total_tokens) ?? 0))
                    for m in src.models {
                        modelTotals.append((m.model, Int64(m.total_tokens) ?? 0))
                    }
                }
                modelTotals.sort { $0.1 > $1.1 }
                sourceTotals.sort { $0.1 > $1.1 }

                let s = UsageSummary(
                    today: Int64(todayR.totals.total_tokens) ?? 0,
                    sevenDay: Int64(weekR.totals.total_tokens) ?? 0,
                    thirtyDay: Int64(monthR.totals.total_tokens) ?? 0,
                    total: Int64(totalR.totals.total_tokens) ?? 0,
                    byModel: Array(modelTotals.prefix(5)),
                    sources: Array(sourceTotals.prefix(8)),
                    activeDays7: activeDays,
                    lastSyncAt: Date()
                )
                FileHandle.standardError.write(Data("[tokenboard] ✓ today=\(s.today) total=\(s.total)\n".utf8))
                await MainActor.run {
                    self?.summary = s
                    self?.loading = false
                }
            } catch {
                let msg = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                FileHandle.standardError.write(Data("[tokenboard] ✗ error: \(msg)\n".utf8))
                await MainActor.run {
                    self?.lastError = msg
                    self?.loading = false
                }
            }
        }
    }

    private static func todayLocal() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        f.timeZone = TimeZone.current
        return f.string(from: Date())
    }

    /// Local-day arithmetic: subtract whole days using calendar (handles DST
    /// changes correctly), then format in the user's local timezone.
    private static func daysAgoLocal(_ n: Int) -> String {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone.current
        let date = cal.date(byAdding: .day, value: -n, to: Date()) ?? Date()
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        f.timeZone = TimeZone.current
        return f.string(from: date)
    }
}

enum Formatter {
    static let abs = NumberFormatter()

    static func full(_ v: Int64) -> String {
        let nf = NumberFormatter()
        nf.numberStyle = .decimal
        return nf.string(from: NSNumber(value: v)) ?? String(v)
    }

    static func compact(_ v: Int64) -> String {
        let abs = v < 0 ? -v : v
        if abs < 1_000 { return String(v) }
        if abs < 1_000_000 { return String(format: "%.1fK", Double(v) / 1_000) }
        if abs < 1_000_000_000 { return String(format: "%.1fM", Double(v) / 1_000_000) }
        return String(format: "%.2fB", Double(v) / 1_000_000_000)
    }
}
